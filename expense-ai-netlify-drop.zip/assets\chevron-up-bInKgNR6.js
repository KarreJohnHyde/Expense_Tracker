import{c as o}from"./index-BcJI3t6j.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],r=o("chevron-down",n);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],t=o("chevron-up",c);export{r as C,t as a};
